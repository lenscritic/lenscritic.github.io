use strict;
use warnings;
use Getopt::Long;

my %args;
GetOptions(\%args,
           "rompath=s",
           "mode=s",
           "extension=s"
) or die "Invalid arguments!";
die "Missing -rompath!" unless $args{rompath};
die "Missing -mode!" unless $args{mode};
die "Missing -extension!" unless $args{extension};

my $mode = $args{mode};
my $extension = $args{extension};
my $directory = $args{rompath};

# add ending "/" if missing from passed directory
if ($directory !~ /.*\/$/) {
  $directory = $directory . "/";
}

my $file;
my %nameLookup;
my %gameResults;

if ($mode eq "mame") {
  $file = 'association_data';
  open my $data, $file or die "Could not open $file: $!";
  # read all mame associations into hash
  my $throwaway = <$data>;
  while( my $line = <$data>)  {   
    my ($filename, $fullname) = ($line =~ /(\w+)\s+\"(.*)\"/); 
    $nameLookup{$filename} = $fullname;
  }
  close $data;
} elsif ($mode eq "fba") {
  $file = 'fba_original';
  open my $data, $file or die "Could not open $file: $!";
  # read all fba associations into hash
  while( my $line = <$data>)  {   
    my ($filename, $fullname) = ($line =~ /(\w+),(.+),.*/); 
    $nameLookup{$filename} = $fullname;
  }
}

# read all local rom files and build new hash
# paperboy -> Paperboy (rev 3)
opendir(DIR,$directory);
my @files = readdir(DIR);
closedir(DIR);
foreach(@files){
  if ($_ =~ /^(.*)\.($extension)$/) {
    if (exists $nameLookup{$1})  # this lookup will only work for mame and fba
    {
      $gameResults{$1} = $nameLookup{$1};
    } else {
      $gameResults{$1} = $1;  # if you can't find name in lookup, use filename
    }
  }
}

# append image references if applicable
foreach(@files){
  if ($_ =~ /^(.*)\.(png|jpg|jpeg|bmp)$/i) {
    if (exists $gameResults{$1})
    {
      $gameResults{$1} = $gameResults{$1} . "|||$2";
    } 
  } 
}

# write out xml 
print "<?xml version=\"1.0\"?>\n";
print "<gameList>\n";
foreach my $key ( sort {$gameResults{$a} cmp $gameResults{$b}} keys %gameResults) {
   #print $key . '=' . $gameResults{$key} . "\n";
   my @val = split('\|\|\|', $gameResults{$key});
   print "   <game>\n";
   print "      <path>" . $directory . $key . "." . $extension . "</path>\n";
   print "      <name>" . $val[0] . "</name>\n";
   if ($#val == 1)
   {
      print "      <image>" . $directory . $key . "." . $val[1] . "</image>\n";
   }
   print "      <rating>0.000000</rating>\n";
   print "      <userrating>0.000000</userrating>\n";
   print "      <timesplayed>0</timesplayed>\n";
   print "      <lastplayed>0</lastplayed>\n";
   print "   </game>\n";
} 
print "</gameList>\n";

